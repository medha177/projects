const { MongoClient } = require("mongodb");
const mysql = require("mysql2");
const readline = require("readline");

const mongoUri = "mongodb://localhost:27017";
const mongoClient = new MongoClient(mongoUri);
const sqlConnection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "medha", // Replace with your actual MySQL password
    database: "moviesdb1"
});

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

async function fetchMovieById(movieId) {
    try {
        console.log("\n🔄 Fetching from MongoDB...");
        await mongoClient.connect();
        const database = mongoClient.db("movieDB");
        const movieMongo = await database.collection("movies").findOne({ _id: parseInt(movieId) });

        let movieDetails = {};

        if (movieMongo) {
            movieDetails = {
                name: movieMongo.movie_name,
                genre: movieMongo.genre,
                info: movieMongo.movie_info
            };
        } else {
            console.log("❌ No movie found in MongoDB.");
        }

        console.log("\n🔄 Fetching from MySQL...");
        sqlConnection.query(
            "SELECT MovieName, Genre, MovieInformation FROM moviesdb1 WHERE MovieID = ?",
            [movieId],
            (err, results) => {
                if (err) {
                    console.error("❌ SQL Error:", err);
                } else if (results.length > 0) {
                    movieDetails = {
                        name: results[0].MovieName,
                        genre: results[0].Genre,
                        info: results[0].MovieInformation
                    };
                } else {
                    console.log("❌ No movie found in MySQL.");
                }

                sqlConnection.end();
                mongoClient.close();

                if (movieDetails.name) {
                    console.log("\n🎬 Final Movie Details:");
                    console.log(`📌 Name: ${movieDetails.name}`);
                    console.log(`🎭 Genre: ${movieDetails.genre}`);
                    console.log(`📝 Information: ${movieDetails.info}`);
                } else {
                    console.log("No matching movie found in both databases.");
                }

                rl.close();
            }
        );
    } catch (error) {
        console.error("❌ Error connecting to databases:", error);
        sqlConnection.end();
        mongoClient.close();
        rl.close();
    }
}

rl.question("Enter Movie ID to fetch details: ", (movieId) => {
    fetchMovieById(movieId);
});