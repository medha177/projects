const readline = require("readline");

// Hardcoded movie database
const movieDatabase = {
    "1": { movie_name: "Inception", genre: "Sci-Fi", movie_info: "A mind-bending thriller about dreams within dreams." },
    "2": { movie_name: "Interstellar", genre: "Sci-Fi", movie_info: "A space epic exploring time dilation and survival beyond Earth." },
    "3": { movie_name: "The Dark Knight", genre: "Action", movie_info: "Batman faces off against the Joker in a psychological battle." },
    "4": { movie_name: "Titanic", genre: "Romance", movie_info: "A love story set against the tragic sinking of the Titanic." },
    "5": { movie_name: "Avengers: Endgame", genre: "Superhero", movie_info: "The ultimate battle between heroes and Thanos." }
};

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function fetchMovieById(movieId) {
    console.log("\n🔄 Fetching from Hadoop HDFS...");
    if (movieDatabase[movieId]) {
        const movieDetails = movieDatabase[movieId];
        console.log("\n🎬 Final Movie Details:");
        console.log(`📌 Name: ${movieDetails.movie_name}`);
        console.log(`🎭 Genre: ${movieDetails.genre}`);
        console.log(`📝 Information: ${movieDetails.movie_info}`);
    } else {
        console.log("❌ No movie found with that ID.");
    }
    rl.close();
}

rl.question("Enter Movie ID to fetch details: ", (movieId) => {
    fetchMovieById(movieId);
});