import cv2
import numpy as np
import mediapipe as mp

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=1)
mp_draw = mp.solutions.drawing_utils
canvas = np.zeros((720, 1280, 3), dtype=np.uint8)
prev_x, prev_y = None, None
current_color = (255, 0, 0)

cap = cv2.VideoCapture(0)
cap.set(3, 1280)
cap.set(4, 720)

def count_fingers_up(hand_landmarks):
    fingers = [
        mp_hands.HandLandmark.INDEX_FINGER_TIP,
        mp_hands.HandLandmark.MIDDLE_FINGER_TIP,
        mp_hands.HandLandmark.RING_FINGER_TIP,
    ]
    up_count = 0
    for tip in fingers:
        tip_y = hand_landmarks.landmark[tip].y
        pip_y = hand_landmarks.landmark[tip - 2].y
        if tip_y < pip_y:
            up_count += 1
    return up_count

while True:
    ret, frame = cap.read()
    if not ret:
        break
    frame = cv2.flip(frame, 1)
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = hands.process(rgb)

    mode = "idle"

    if result.multi_hand_landmarks:
        for hand_landmarks in result.multi_hand_landmarks:
            mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

            h, w, _ = frame.shape
            index_tip = hand_landmarks.landmark[mp_hands.HandLandmark.INDEX_FINGER_TIP]
            x, y = int(index_tip.x * w), int(index_tip.y * h)

            if x < 100 and y < 100:
                current_color = (0, 0, 255)
            elif x > 1180 and y < 100:
                current_color = (0, 255, 0)
            elif x < 100 and y > 620:
                current_color = (255, 0, 0)
            elif x > 1180 and y > 620:
                current_color = (0, 255, 255)

            finger_count = count_fingers_up(hand_landmarks)

            if finger_count == 1:
                mode = "draw"
            elif finger_count == 2:
                mode = "erase"
            elif finger_count == 3:
                mode = "clear"
                canvas = np.zeros((720, 1280, 3), dtype=np.uint8)
                prev_x, prev_y = None, None
                cv2.putText(frame, "Canvas Cleared", (50, 100),
                            cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 0, 255), 3)
            else:
                mode = "idle"
                prev_x, prev_y = None, None

            if mode in ["draw", "erase"]:
                color = current_color if mode == "draw" else (0, 0, 0)
                thickness = 5 if mode == "draw" else 30
                if prev_x is not None and prev_y is not None:
                    cv2.line(canvas, (prev_x, prev_y), (x, y), color, thickness)
                prev_x, prev_y = x, y

    else:
        prev_x, prev_y = None, None

    cv2.rectangle(frame, (10, 10), (60, 60), current_color, -1)
    cv2.putText(frame, "Color", (70, 45), cv2.FONT_HERSHEY_SIMPLEX, 0.7, current_color, 2)

    if mode == "draw":
        cv2.putText(frame, "Draw Mode", (50, 650), cv2.FONT_HERSHEY_SIMPLEX, 1.2, current_color, 3)
    elif mode == "erase":
        cv2.putText(frame, "Erase Mode", (50, 650), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 0), 3)
    elif mode == "clear":
        cv2.putText(frame, "Canvas Cleared", (50, 650), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 255), 3)
    elif mode == "idle":
        cv2.putText(frame, "Idle Mode (fist closed)", (50, 650), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (100, 100, 100), 2)

    gray_canvas = cv2.cvtColor(canvas, cv2.COLOR_BGR2GRAY)
    _, mask = cv2.threshold(gray_canvas, 20, 255, cv2.THRESH_BINARY)
    inv_mask = cv2.bitwise_not(mask)
    bg = cv2.bitwise_and(frame, frame, mask=inv_mask)
    fg = cv2.bitwise_and(canvas, canvas, mask=mask)
    combined = cv2.add(bg, fg)

    cv2.imshow("AirCanvas", combined)

    if cv2.waitKey(1) & 0xFF == 27:
        break

cap.release()
cv2.destroyAllWindows()